from flask import Flask, render_template, request, redirect, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# db config
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///todoapp2.db"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


# Create db on first request
@app.before_first_request
def create_tables():
    db.create_all()


# Model
class Task(db.Model):
	id = db.Column(db.Integer, primary_key = True)
	title = db.Column(db.String(100), nullable = True)
	created_date = db.Column(db.DateTime, default = datetime.utcnow)
	task_status = db.Column(db.String, default='start')
	def __repr__(self) -> str:
		return f"{self.id} - {self.title} - {self.task_status}"


# Index page + Create a task
@app.route('/', methods=['GET', 'POST'])
def tasks():
    if request.method == 'POST':
        data = request.get_json()
        title = data.get('title')
        if title:
            task = Task(title=title)
            db.session.add(task)
            db.session.commit()
            response = jsonify({"message": "Task added successfully"})
        else:
            response = jsonify({"message": "Title is required in the request."})

        response.headers.add("Access-Control-Allow-Origin", "*")  # Allow requests from any origin
        return response

    task_list = Task.query.all()
    tasks = [{"id": task.id, "title": task.title, "created_date": task.created_date, "curr_status": task.task_status} for task in task_list]
    response = jsonify({"tasks": tasks})
    response.headers.add("Access-Control-Allow-Origin", "*")  # Allow requests from any origin
    return response				


# Edit task
@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    task = Task.query.filter_by(id=id).first()

    if request.method == 'POST':
        data = request.get_json()
        title = data.get('title')
        task_status = data.get('task_status')

        if title:
            task.title = title
            task.task_status = task_status
            db.session.commit()
            return jsonify({"message": "Task edited successfully"})

    return jsonify({"task": {"id": task.id, "title": task.title, "created_date": task.created_date, "task_status": task.task_status}})
					


# Delete task
@app.route('/delete/<int:id>', methods=['POST'])
def delete(id):
    task = Task.query.filter_by(id=id).first()
    
    if task:
        db.session.delete(task)
        db.session.commit()
        return make_response("Task deleted", 200)

    return jsonify({"message": "Task not found"})				


# Main app
if __name__ == '__main__':
	app.run(debug=True, port=8000)





