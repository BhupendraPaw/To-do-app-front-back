# Todo App 
A simple task management application(crud) in Python Flask framework.

#### Built With
- Python
- Flask
- Html
- CSS

#### Setup
- Install packages `pip install -r requirements.txt`
- Start app `python app.py`
- Hit it on browser `http://127.0.0.1:8000/`
"# Todo-app-back" 
