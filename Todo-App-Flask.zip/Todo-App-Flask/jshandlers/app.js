document.addEventListener("DOMContentLoaded", function () {
    const taskForm = document.getElementById("taskForm");
    const taskTitleInput = document.getElementById("taskTitle");
    const taskList = document.getElementById("taskList");

    // Function to display tasks
    function displayTasks() {
        fetch('/', {
            method: 'GET',
        })
            .then(response => response.json())
            .then(data => {
                const tasks = data.tasks;
                taskList.innerHTML = ''; // Clear existing task list

                tasks.forEach(task => {
                    const taskItem = document.createElement("div");
                    taskItem.innerHTML = `
                        <p>ID: ${task.id}</p>
                        <p>Title: ${task.title}</p>
                        <p>Created Date: ${task.created_date}</p>
                        <p>Status: ${task.curr_status}</p>
                    `;
                    taskList.appendChild(taskItem);
                });
            })
            .catch(error => {
                console.error("Error fetching tasks:", error);
            });
    }

    taskForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const title = taskTitleInput.value;

        if (title.trim() !== "") {
            fetch('/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ title: title }),
            })
                .then(response => response.json())
                .then(data => {
                    console.log(data.message);
                    // Redirect to index.html
                    window.location.href = "index.html";
                })
                .catch(error => {
                    console.error("Error adding task:", error);
                });
        } else {
            alert("Please enter a task title.");
        }
    });

    // Display tasks on page load
    displayTasks();
});
